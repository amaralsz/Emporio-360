import Link from "next/link"
import Button from "../src/components/ui/Button"

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center px-4">
        <h1 className="text-6xl font-bold mb-6">
          <span className="gold-gradient-text">404</span>
        </h1>
        <h2 className="text-2xl font-semibold mb-4 text-text">Página não encontrada</h2>
        <p className="text-text-muted max-w-md mx-auto mb-8">
          A página que você está procurando não existe ou foi movida para outro endereço.
        </p>
        <Link href="/">
          <Button size="lg">Voltar para a página inicial</Button>
        </Link>
      </div>
    </div>
  )
}
