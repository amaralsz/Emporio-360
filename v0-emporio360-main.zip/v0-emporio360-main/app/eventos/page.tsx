"use client"

import Link from "next/link"
import Navbar from "../../src/components/layout/Navbar"
import Footer from "../../src/components/layout/Footer"
import Button from "../../src/components/ui/Button"
import Card from "../../src/components/ui/Card"
import Badge from "../../src/components/ui/Badge"
import { useAuth, ROLES } from "../../src/contexts/AuthContext"

export default function EventosPage() {
  // Dados de exemplo
  const eventos = [
    {
      id: 1,
      titulo: "Workshop de Design Thinking",
      data: "15 de Junho, 2023",
      local: "São Paulo, SP",
      categoria: "Workshop",
      modalidade: "Presencial",
      imagem:
        "https://images.unsplash.com/photo-1540317580384-e5d43867caa6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    },
    {
      id: 2,
      titulo: "Conferência de Tecnologia",
      data: "22 de Julho, 2023",
      local: "Rio de Janeiro, RJ",
      categoria: "Conferência",
      modalidade: "Presencial",
      imagem:
        "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    },
    {
      id: 3,
      titulo: "Webinar: Inteligência Artificial",
      data: "10 de Agosto, 2023",
      local: "Online",
      categoria: "Webinar",
      modalidade: "Online",
      imagem:
        "https://images.unsplash.com/photo-1591453089816-0fbb971b454c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    },
    {
      id: 4,
      titulo: "Meetup de Empreendedorismo",
      data: "5 de Setembro, 2023",
      local: "Belo Horizonte, MG",
      categoria: "Meetup",
      modalidade: "Presencial",
      imagem:
        "https://images.unsplash.com/photo-1528605248644-14dd04022da1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    },
  ]

  const { user, isAuthenticated } = useAuth()
  const canCreateContent = isAuthenticated && user.role !== ROLES.VISITANTE

  return (
    <>
      <Navbar />
      <main className="min-h-screen py-12 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">
                <span className="gold-gradient-text">Eventos</span>
              </h1>
              <p className="text-text-muted">Descubra eventos presenciais e online para expandir seu conhecimento.</p>
            </div>
            {canCreateContent ? (
              <Link href="/criar/evento" className="mt-4 md:mt-0">
                <Button className="flex items-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5 mr-2"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                  Criar Evento
                </Button>
              </Link>
            ) : (
              isAuthenticated && (
                <div className="mt-4 md:mt-0 text-text-muted text-sm">
                  Você está logado como visitante e não pode criar eventos.
                </div>
              )
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {eventos.map((evento) => (
              <Card key={evento.id} variant="elevated" hover className="overflow-hidden">
                <div className="flex flex-col md:flex-row">
                  <div className="md:w-1/3 h-48 md:h-auto">
                    <img
                      src={evento.imagem || "/placeholder.svg"}
                      alt={evento.titulo}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="md:w-2/3 p-6">
                    <div className="flex flex-wrap gap-2 mb-3">
                      <Badge variant="primary">{evento.categoria}</Badge>
                      <Badge variant={evento.modalidade === "Online" ? "secondary" : "outline"}>
                        {evento.modalidade}
                      </Badge>
                    </div>

                    <h3 className="text-xl font-semibold mb-2 text-text">{evento.titulo}</h3>

                    <div className="flex items-center mb-2">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 text-primary mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                        />
                      </svg>
                      <span className="text-text-muted">{evento.data}</span>
                    </div>

                    <div className="flex items-center mb-4">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 text-primary mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                        />
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                        />
                      </svg>
                      <span className="text-text-muted">{evento.local}</span>
                    </div>

                    <Button>Ver Detalhes</Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
