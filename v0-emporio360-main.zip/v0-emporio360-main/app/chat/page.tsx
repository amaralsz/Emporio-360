"use client"

import { useState } from "react"
import Link from "next/link"
import Navbar from "../../src/components/layout/Navbar"
import Footer from "../../src/components/layout/Footer"
import Card from "../../src/components/ui/Card"
import Button from "../../src/components/ui/Button"

export default function ChatPage() {
  const [activeTab, setActiveTab] = useState("chat")

  return (
    <>
      <Navbar />
      <main className="min-h-screen py-12 bg-background">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">
              <span className="gold-gradient-text">Comunidade</span>
            </h1>
            <p className="text-text-muted">
              Conecte-se com outros membros, participe de discussões e compartilhe conhecimento.
            </p>
          </div>

          {/* Tabs */}
          <div className="flex border-b border-primary/20 mb-6">
            <button
              className={`px-6 py-3 font-medium ${
                activeTab === "chat" ? "text-primary border-b-2 border-primary" : "text-text-muted hover:text-text"
              }`}
              onClick={() => setActiveTab("chat")}
            >
              Chat
            </button>
            <Link href="/chat/blog">
              <button
                className={`px-6 py-3 font-medium ${
                  activeTab === "blog" ? "text-primary border-b-2 border-primary" : "text-text-muted hover:text-text"
                }`}
              >
                Blog
              </button>
            </Link>
            <button
              className={`px-6 py-3 font-medium ${
                activeTab === "grupos" ? "text-primary border-b-2 border-primary" : "text-text-muted hover:text-text"
              }`}
              onClick={() => setActiveTab("grupos")}
            >
              Grupos
            </button>
            <button
              className={`px-6 py-3 font-medium ${
                activeTab === "eventos" ? "text-primary border-b-2 border-primary" : "text-text-muted hover:text-text"
              }`}
              onClick={() => setActiveTab("eventos")}
            >
              Eventos
            </button>
          </div>

          {/* Content based on active tab */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              {activeTab === "chat" && (
                <Card className="p-6">
                  <div className="text-center py-12">
                    <h2 className="text-2xl font-semibold mb-4">Bem-vindo ao Chat da Comunidade</h2>
                    <p className="text-text-muted mb-8 max-w-md mx-auto">
                      Conecte-se com outros membros, faça perguntas e participe de discussões em tempo real.
                    </p>
                    <div className="flex flex-col sm:flex-row justify-center gap-4">
                      <Button>Entrar no Chat Geral</Button>
                      <Button variant="outline">Explorar Salas Temáticas</Button>
                    </div>
                  </div>
                </Card>
              )}

              {activeTab === "grupos" && (
                <Card className="p-6">
                  <div className="text-center py-12">
                    <h2 className="text-2xl font-semibold mb-4">Grupos de Discussão</h2>
                    <p className="text-text-muted mb-8 max-w-md mx-auto">
                      Participe de grupos temáticos para discutir assuntos específicos com pessoas que compartilham seus
                      interesses.
                    </p>
                    <div className="flex flex-col sm:flex-row justify-center gap-4">
                      <Button>Explorar Grupos</Button>
                      <Button variant="outline">Criar Novo Grupo</Button>
                    </div>
                  </div>
                </Card>
              )}

              {activeTab === "eventos" && (
                <Card className="p-6">
                  <div className="text-center py-12">
                    <h2 className="text-2xl font-semibold mb-4">Eventos da Comunidade</h2>
                    <p className="text-text-muted mb-8 max-w-md mx-auto">
                      Descubra eventos virtuais organizados pela comunidade, como webinars, meetups e workshops.
                    </p>
                    <div className="flex flex-col sm:flex-row justify-center gap-4">
                      <Button>Ver Próximos Eventos</Button>
                      <Button variant="outline">Propor um Evento</Button>
                    </div>
                  </div>
                </Card>
              )}
            </div>

            <div className="md:col-span-1">
              <Card className="p-4 mb-6">
                <h3 className="text-lg font-semibold mb-3">Recursos da Comunidade</h3>
                <ul className="space-y-2">
                  <li>
                    <Link
                      href="/chat/blog"
                      className="flex items-center text-text hover:text-primary transition-colors"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 mr-2 text-primary"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"
                        />
                      </svg>
                      Blog da Comunidade
                    </Link>
                  </li>
                  <li>
                    <Link href="#" className="flex items-center text-text hover:text-primary transition-colors">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 mr-2 text-primary"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                        />
                      </svg>
                      Calendário de Eventos
                    </Link>
                  </li>
                  <li>
                    <Link href="#" className="flex items-center text-text hover:text-primary transition-colors">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 mr-2 text-primary"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                        />
                      </svg>
                      Documentação e Guias
                    </Link>
                  </li>
                  <li>
                    <Link href="#" className="flex items-center text-text hover:text-primary transition-colors">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 mr-2 text-primary"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                        />
                      </svg>
                      FAQ e Suporte
                    </Link>
                  </li>
                </ul>
              </Card>

              <Card className="p-4">
                <h3 className="text-lg font-semibold mb-3">Tópicos em Alta</h3>
                <div className="space-y-3">
                  <div className="border-b border-primary/10 pb-2">
                    <Link href="#" className="font-medium text-text hover:text-primary">
                      Novidades em IA generativa
                    </Link>
                    <div className="flex justify-between text-text-muted text-sm mt-1">
                      <span>32 participantes</span>
                      <span>Ativo agora</span>
                    </div>
                  </div>
                  <div className="border-b border-primary/10 pb-2">
                    <Link href="#" className="font-medium text-text hover:text-primary">
                      Mercado de trabalho em tecnologia
                    </Link>
                    <div className="flex justify-between text-text-muted text-sm mt-1">
                      <span>18 participantes</span>
                      <span>Há 20 min</span>
                    </div>
                  </div>
                  <div className="border-b border-primary/10 pb-2">
                    <Link href="#" className="font-medium text-text hover:text-primary">
                      Dicas para empreendedores iniciantes
                    </Link>
                    <div className="flex justify-between text-text-muted text-sm mt-1">
                      <span>24 participantes</span>
                      <span>Há 1 hora</span>
                    </div>
                  </div>
                  <div>
                    <Link
                      href="/chat/blog"
                      className="text-primary hover:text-primary-light flex items-center justify-center mt-2"
                    >
                      Ver todos os tópicos
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4 ml-1"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </Link>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
