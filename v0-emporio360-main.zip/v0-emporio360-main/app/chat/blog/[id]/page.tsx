"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import Navbar from "../../../../src/components/layout/Navbar"
import Footer from "../../../../src/components/layout/Footer"
import BlogPost from "../../../../src/components/blog/BlogPost"
import Card from "../../../../src/components/ui/Card"
import Badge from "../../../../src/components/ui/Badge"
import Button from "../../../../src/components/ui/Button"

// Dados de exemplo para o blog (mesmo do arquivo anterior)
const blogPosts = [
  {
    id: "post-1",
    author: {
      id: "user-1",
      name: "João Silva",
      avatar:
        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
    },
    title: "Como a inteligência artificial está transformando a educação",
    content: `<p>A inteligência artificial (IA) está revolucionando a forma como aprendemos e ensinamos. Desde sistemas de tutoria personalizados até ferramentas de avaliação automatizadas, a IA está tornando a educação mais acessível, eficiente e adaptável às necessidades individuais dos alunos.</p>
    
    <h2 class="text-xl font-semibold mt-4 mb-2">Personalização do aprendizado</h2>
    <p>Um dos maiores benefícios da IA na educação é a capacidade de personalizar o aprendizado para cada aluno. Algoritmos inteligentes podem analisar o desempenho, identificar pontos fortes e fracos, e adaptar o conteúdo para atender às necessidades específicas de cada estudante.</p>
    
    <h2 class="text-xl font-semibold mt-4 mb-2">Automação de tarefas administrativas</h2>
    <p>Professores frequentemente gastam horas em tarefas administrativas como correção de provas e gerenciamento de notas. A IA pode automatizar muitas dessas tarefas, permitindo que os educadores dediquem mais tempo à instrução e ao apoio direto aos alunos.</p>
    
    <h2 class="text-xl font-semibold mt-4 mb-2">Acessibilidade global</h2>
    <p>Plataformas educacionais baseadas em IA estão tornando a educação de qualidade acessível a estudantes em todo o mundo, independentemente de sua localização geográfica ou recursos financeiros.</p>
    
    <h2 class="text-xl font-semibold mt-4 mb-2">Desafios e considerações éticas</h2>
    <p>Apesar dos benefícios, a implementação da IA na educação também apresenta desafios, incluindo preocupações com privacidade de dados, viés algorítmico e o papel em evolução dos educadores humanos.</p>
    
    <h2 class="text-xl font-semibold mt-4 mb-2">Conclusão</h2>
    <p>À medida que a tecnologia continua a evoluir, a IA tem o potencial de transformar fundamentalmente nossos sistemas educacionais, tornando-os mais eficazes, inclusivos e adaptáveis às necessidades do século XXI.</p>`,
    image:
      "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80",
    date: "Há 2 horas",
    category: "Tecnologia",
    likes: 24,
    comments: [
      {
        id: "comment-1",
        author: {
          id: "user-2",
          name: "Maria Oliveira",
          avatar:
            "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
        },
        content: "Excelente artigo! Estou usando IA em minha sala de aula e os resultados são impressionantes.",
        date: "Há 1 hora",
        likes: 5,
        replies: [
          {
            id: "reply-1",
            author: {
              id: "user-1",
              name: "João Silva",
              avatar:
                "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
            },
            content: "Obrigado, Maria! Quais ferramentas específicas você está utilizando?",
            date: "Há 45 minutos",
            likes: 2,
          },
        ],
      },
    ],
  },
  {
    id: "post-2",
    author: {
      id: "user-3",
      name: "Carlos Mendes",
      avatar:
        "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
    },
    title: "5 dicas para melhorar sua produtividade trabalhando em casa",
    content: `<p>O trabalho remoto veio para ficar, mas muitas pessoas ainda enfrentam desafios para manter a produtividade em casa. Neste post, compartilho 5 estratégias que transformaram minha rotina de home office e podem ajudar você também.</p>
    
    <h2 class="text-xl font-semibold mt-4 mb-2">1. Estabeleça uma rotina clara</h2>
    <p>Manter horários consistentes para começar e terminar o trabalho ajuda seu cérebro a entrar no "modo trabalho" e sair dele no final do dia. Inclua rituais de início e fim de expediente para criar transições claras.</p>
    
    <h2 class="text-xl font-semibold mt-4 mb-2">2. Crie um espaço dedicado ao trabalho</h2>
    <p>Mesmo que seja apenas um canto da mesa da cozinha, ter um espaço designado exclusivamente para o trabalho ajuda a separar a vida profissional da pessoal e a manter o foco.</p>
    
    <h2 class="text-xl font-semibold mt-4 mb-2">3. Use a técnica Pomodoro</h2>
    <p>Trabalhe em blocos de 25 minutos com foco total, seguidos por pausas de 5 minutos. Após quatro blocos, faça uma pausa mais longa. Esta técnica mantém a mente fresca e evita a fadiga mental.</p>
    
    <h2 class="text-xl font-semibold mt-4 mb-2">4. Minimize as distrações digitais</h2>
    <p>Desligue notificações, use aplicativos de bloqueio de sites distrativos e mantenha apenas as abas necessárias abertas no navegador durante os períodos de trabalho focado.</p>
    
    <h2 class="text-xl font-semibold mt-4 mb-2">5. Priorize seu bem-estar</h2>
    <p>Inclua exercícios físicos, alimentação saudável e pausas regulares em sua rotina. Um corpo e mente saudáveis são essenciais para manter altos níveis de produtividade a longo prazo.</p>`,
    date: "Ontem",
    category: "Produtividade",
    likes: 18,
    comments: [],
  },
]

// Posts relacionados
const relatedPosts = [
  {
    id: "related-1",
    title: "O futuro da educação online pós-pandemia",
    author: "Ana Souza",
    date: "3 dias atrás",
    category: "Educação",
  },
  {
    id: "related-2",
    title: "Como implementar IA em pequenas empresas",
    author: "Roberto Almeida",
    date: "1 semana atrás",
    category: "Tecnologia",
  },
  {
    id: "related-3",
    title: "Ferramentas essenciais para educadores em 2023",
    author: "Juliana Costa",
    date: "2 semanas atrás",
    category: "Educação",
  },
]

export default function BlogPostPage() {
  const params = useParams()
  const [post, setPost] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulando busca do post pelo ID
    const fetchPost = () => {
      setLoading(true)
      setTimeout(() => {
        const foundPost = blogPosts.find((p) => p.id === params.id)
        setPost(foundPost || null)
        setLoading(false)
      }, 500)
    }

    fetchPost()
  }, [params.id])

  if (loading) {
    return (
      <>
        <Navbar />
        <main className="min-h-screen py-12 bg-background">
          <div className="container mx-auto px-4">
            <div className="flex justify-center items-center h-64">
              <div className="animate-pulse text-primary">Carregando...</div>
            </div>
          </div>
        </main>
        <Footer />
      </>
    )
  }

  if (!post) {
    return (
      <>
        <Navbar />
        <main className="min-h-screen py-12 bg-background">
          <div className="container mx-auto px-4">
            <div className="text-center py-12">
              <h1 className="text-3xl font-bold mb-4">Publicação não encontrada</h1>
              <p className="text-text-muted mb-6">A publicação que você está procurando não existe ou foi removida.</p>
              <Link href="/chat/blog">
                <Button>Voltar para o Blog</Button>
              </Link>
            </div>
          </div>
        </main>
        <Footer />
      </>
    )
  }

  return (
    <>
      <Navbar />
      <main className="min-h-screen py-12 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Main content */}
            <div className="md:w-2/3">
              <div className="mb-6">
                <Link href="/chat/blog" className="text-primary hover:text-primary-light flex items-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5 mr-1"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M10 19l-7-7m0 0l7-7m-7 7h18"
                    />
                  </svg>
                  Voltar para o Blog
                </Link>
              </div>

              <BlogPost {...post} isDetailed={true} />
            </div>

            {/* Sidebar */}
            <div className="md:w-1/3 space-y-6">
              {/* Author info */}
              <Card className="p-4">
                <h3 className="text-lg font-semibold mb-3">Sobre o Autor</h3>
                <div className="flex items-center mb-3">
                  <img
                    src={post.author.avatar || "/placeholder.svg"}
                    alt={post.author.name}
                    className="w-12 h-12 rounded-full mr-3"
                  />
                  <div>
                    <Link href={`/perfil/${post.author.id}`} className="font-medium text-text hover:text-primary">
                      {post.author.name}
                    </Link>
                    <p className="text-text-muted text-sm">Membro desde 2022</p>
                  </div>
                </div>
                <p className="text-text-muted mb-3">
                  Especialista em tecnologia educacional e entusiasta de IA aplicada à educação.
                </p>
                <Button variant="outline" className="w-full">
                  Ver Perfil
                </Button>
              </Card>

              {/* Related posts */}
              <Card className="p-4">
                <h3 className="text-lg font-semibold mb-3">Publicações Relacionadas</h3>
                <div className="space-y-4">
                  {relatedPosts.map((relatedPost) => (
                    <div key={relatedPost.id} className="border-b border-primary/10 pb-3 last:border-0 last:pb-0">
                      <Link href={`/chat/blog/${relatedPost.id}`}>
                        <h4 className="font-medium hover:text-primary transition-colors">{relatedPost.title}</h4>
                      </Link>
                      <div className="flex justify-between text-text-muted text-sm mt-1">
                        <span>{relatedPost.author}</span>
                        <span>{relatedPost.date}</span>
                      </div>
                      <Badge variant="secondary" className="mt-2">
                        {relatedPost.category}
                      </Badge>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Share */}
              <Card className="p-4">
                <h3 className="text-lg font-semibold mb-3">Compartilhar</h3>
                <div className="flex space-x-2">
                  <Button variant="outline" className="flex-1 flex justify-center items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5 mr-1"
                      fill="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z" />
                    </svg>
                    Facebook
                  </Button>
                  <Button variant="outline" className="flex-1 flex justify-center items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5 mr-1"
                      fill="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z" />
                    </svg>
                    Twitter
                  </Button>
                </div>
                <Button variant="outline" className="w-full mt-2 flex justify-center items-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5 mr-1"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
                    />
                  </svg>
                  Copiar Link
                </Button>
              </Card>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
