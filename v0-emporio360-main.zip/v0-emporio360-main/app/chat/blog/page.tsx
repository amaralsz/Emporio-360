"use client"

import { useState } from "react"
import Navbar from "../../../src/components/layout/Navbar"
import Footer from "../../../src/components/layout/Footer"
import BlogPost from "../../../src/components/blog/BlogPost"
import CreatePostForm from "../../../src/components/blog/CreatePostForm"
import Card from "../../../src/components/ui/Card"
import Badge from "../../../src/components/ui/Badge"
import Button from "../../../src/components/ui/Button"
import Link from "next/link"

// Adicione no topo do arquivo, após os imports existentes
import { useAuth, ROLES } from "../../../src/contexts/AuthContext"

// Dados de exemplo para o blog
const initialPosts = [
  {
    id: "post-1",
    author: {
      id: "user-1",
      name: "João Silva",
      avatar:
        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
    },
    title: "Como a inteligência artificial está transformando a educação",
    content:
      "A inteligência artificial (IA) está revolucionando a forma como aprendemos e ensinamos. Desde sistemas de tutoria personalizados até ferramentas de avaliação automatizadas, a IA está tornando a educação mais acessível, eficiente e adaptável às necessidades individuais dos alunos. Neste artigo, exploraremos como essas tecnologias estão sendo implementadas em salas de aula ao redor do mundo e quais são os resultados preliminares dessas iniciativas.",
    image:
      "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80",
    date: "Há 2 horas",
    category: "Tecnologia",
    likes: 24,
    comments: [
      {
        id: "comment-1",
        author: {
          id: "user-2",
          name: "Maria Oliveira",
          avatar:
            "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
        },
        content: "Excelente artigo! Estou usando IA em minha sala de aula e os resultados são impressionantes.",
        date: "Há 1 hora",
        likes: 5,
        replies: [
          {
            id: "reply-1",
            author: {
              id: "user-1",
              name: "João Silva",
              avatar:
                "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
            },
            content: "Obrigado, Maria! Quais ferramentas específicas você está utilizando?",
            date: "Há 45 minutos",
            likes: 2,
          },
        ],
      },
    ],
  },
  {
    id: "post-2",
    author: {
      id: "user-3",
      name: "Carlos Mendes",
      avatar:
        "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
    },
    title: "5 dicas para melhorar sua produtividade trabalhando em casa",
    content:
      "O trabalho remoto veio para ficar, mas muitas pessoas ainda enfrentam desafios para manter a produtividade em casa. Neste post, compartilho 5 estratégias que transformaram minha rotina de home office e podem ajudar você também.",
    date: "Ontem",
    category: "Produtividade",
    likes: 18,
    comments: [],
  },
]

// Categorias populares
const popularCategories = [
  { name: "Tecnologia", count: 42 },
  { name: "Educação", count: 38 },
  { name: "Negócios", count: 27 },
  { name: "Produtividade", count: 23 },
  { name: "Saúde", count: 19 },
  { name: "Arte e Cultura", count: 15 },
]

// Usuários ativos
const activeUsers = [
  {
    id: "user-1",
    name: "João Silva",
    avatar:
      "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
    posts: 12,
  },
  {
    id: "user-2",
    name: "Maria Oliveira",
    avatar:
      "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
    posts: 8,
  },
  {
    id: "user-3",
    name: "Carlos Mendes",
    avatar:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
    posts: 15,
  },
]

export default function BlogPage() {
  const [posts, setPosts] = useState(initialPosts)
  const [activeTab, setActiveTab] = useState("recentes")

  // Dentro da função do componente, adicione:
  const { user, isAuthenticated } = useAuth()
  const canCreateContent = isAuthenticated && user.role !== ROLES.VISITANTE

  const handlePostCreated = (newPost) => {
    setPosts([newPost, ...posts])
  }

  return (
    <>
      <Navbar />
      <main className="min-h-screen py-12 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Main content */}
            <div className="md:w-2/3">
              <div className="mb-8">
                <h1 className="text-3xl font-bold mb-2">
                  <span className="gold-gradient-text">Blog da Comunidade</span>
                </h1>
                <p className="text-text-muted">
                  Compartilhe conhecimento, faça perguntas e conecte-se com outros membros da comunidade.
                </p>
              </div>

              {/* Tabs */}
              <div className="flex border-b border-primary/20 mb-6">
                <button
                  className={`px-4 py-2 font-medium ${
                    activeTab === "recentes"
                      ? "text-primary border-b-2 border-primary"
                      : "text-text-muted hover:text-text"
                  }`}
                  onClick={() => setActiveTab("recentes")}
                >
                  Recentes
                </button>
                <button
                  className={`px-4 py-2 font-medium ${
                    activeTab === "populares"
                      ? "text-primary border-b-2 border-primary"
                      : "text-text-muted hover:text-text"
                  }`}
                  onClick={() => setActiveTab("populares")}
                >
                  Populares
                </button>
                <button
                  className={`px-4 py-2 font-medium ${
                    activeTab === "seguindo"
                      ? "text-primary border-b-2 border-primary"
                      : "text-text-muted hover:text-text"
                  }`}
                  onClick={() => setActiveTab("seguindo")}
                >
                  Seguindo
                </button>
              </div>

              {/* Create post form - apenas para usuários cadastradores */}
              {canCreateContent ? (
                <CreatePostForm onPostCreated={handlePostCreated} />
              ) : (
                <Card className="p-6 mb-6">
                  <div className="text-center">
                    {isAuthenticated ? (
                      <>
                        <p className="text-text-muted mb-4">
                          Você está logado como visitante e não tem permissão para criar publicações.
                        </p>
                        <p>
                          <Link href="/auth/login" className="text-primary hover:text-primary-light">
                            Faça login como cadastrador
                          </Link>{" "}
                          para criar conteúdo.
                        </p>
                      </>
                    ) : (
                      <>
                        <p className="text-text-muted mb-4">
                          Faça login para criar publicações e interagir com a comunidade.
                        </p>
                        <div className="flex justify-center space-x-4">
                          <Link href="/auth/login">
                            <Button variant="outline">Entrar</Button>
                          </Link>
                          <Link href="/auth/registrar">
                            <Button>Cadastrar</Button>
                          </Link>
                        </div>
                      </>
                    )}
                  </div>
                </Card>
              )}

              {/* Posts */}
              <div className="space-y-6">
                {posts.length > 0 ? (
                  posts.map((post) => <BlogPost key={post.id} {...post} />)
                ) : (
                  <div className="text-center py-12">
                    <p className="text-text-muted mb-4">Nenhuma publicação encontrada.</p>
                    <p className="text-text">Seja o primeiro a compartilhar algo com a comunidade!</p>
                  </div>
                )}
              </div>
            </div>

            {/* Sidebar */}
            <div className="md:w-1/3 space-y-6">
              {/* About */}
              <Card className="p-4">
                <h3 className="text-lg font-semibold mb-3">Sobre o Blog</h3>
                <p className="text-text-muted mb-4">
                  Um espaço para compartilhar conhecimento, fazer perguntas e conectar-se com outros membros da
                  comunidade Empório 360.
                </p>
                <Button className="w-full">Criar Nova Publicação</Button>
              </Card>

              {/* Popular categories */}
              <Card className="p-4">
                <h3 className="text-lg font-semibold mb-3">Categorias Populares</h3>
                <div className="flex flex-wrap gap-2">
                  {popularCategories.map((category) => (
                    <Link href={`/chat/blog/categoria/${category.name.toLowerCase()}`} key={category.name}>
                      <Badge variant="secondary" className="cursor-pointer">
                        {category.name} ({category.count})
                      </Badge>
                    </Link>
                  ))}
                </div>
              </Card>

              {/* Active users */}
              <Card className="p-4">
                <h3 className="text-lg font-semibold mb-3">Usuários Ativos</h3>
                <div className="space-y-3">
                  {activeUsers.map((user) => (
                    <Link href={`/perfil/${user.id}`} key={user.id}>
                      <div className="flex items-center p-2 hover:bg-primary/5 rounded-md transition-colors">
                        <img
                          src={user.avatar || "/placeholder.svg"}
                          alt={user.name}
                          className="w-10 h-10 rounded-full mr-3"
                        />
                        <div>
                          <p className="font-medium text-text">{user.name}</p>
                          <p className="text-text-muted text-sm">{user.posts} publicações</p>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </Card>

              {/* Rules */}
              <Card className="p-4">
                <h3 className="text-lg font-semibold mb-3">Regras da Comunidade</h3>
                <ul className="space-y-2 text-text-muted">
                  <li className="flex items-start">
                    <span className="text-primary mr-2">•</span>
                    Seja respeitoso com todos os membros
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2">•</span>
                    Compartilhe conteúdo relevante e útil
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2">•</span>
                    Não faça spam ou publicidade não autorizada
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2">•</span>
                    Dê crédito quando usar conteúdo de outros
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2">•</span>
                    Reporte conteúdo inadequado
                  </li>
                </ul>
              </Card>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
