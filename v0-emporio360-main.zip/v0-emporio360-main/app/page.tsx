"use client"

import Navbar from "../src/components/layout/Navbar"
import Footer from "../src/components/layout/Footer"
import HomePage from "../src/pages/HomePage"

export default function Page() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <HomePage />
      </main>
      <Footer />
    </div>
  )
}
