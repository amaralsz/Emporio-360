"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import Navbar from "../../src/components/layout/Navbar"
import Footer from "../../src/components/layout/Footer"
import Card from "../../src/components/ui/Card"
import Button from "../../src/components/ui/Button"
import Avatar from "../../src/components/ui/Avatar"
import Badge from "../../src/components/ui/Badge"
import { useAuth, ROLES } from "../../src/contexts/AuthContext"

export default function ProfilePage() {
  const { user, isAuthenticated, logout } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/auth/login")
    }
  }, [isAuthenticated, router])

  if (!isAuthenticated) {
    return null
  }

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  const getRoleName = (role) => {
    switch (role) {
      case ROLES.ADMIN:
        return "Administrador"
      case ROLES.CADASTRADOR:
        return "Cadastrador"
      case ROLES.VISITANTE:
        return "Visitante"
      default:
        return "Usuário"
    }
  }

  const getRoleColor = (role) => {
    switch (role) {
      case ROLES.ADMIN:
        return "danger"
      case ROLES.CADASTRADOR:
        return "success"
      case ROLES.VISITANTE:
        return "secondary"
      default:
        return "default"
    }
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <div className="flex-grow bg-background py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-3xl font-bold mb-6">
              <span className="gold-gradient-text">Meu Perfil</span>
            </h1>

            <Card className="p-6">
              <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
                <div className="flex-shrink-0">
                  <Avatar
                    src={user.avatar || "/placeholder.svg?height=120&width=120"}
                    alt={user.name}
                    size="xl"
                    className="w-28 h-28"
                  />
                </div>

                <div className="flex-grow">
                  <div className="flex flex-col md:flex-row justify-between items-center mb-4">
                    <div>
                      <h2 className="text-2xl font-bold text-text">{user.name}</h2>
                      <p className="text-text-muted">{user.email}</p>
                    </div>

                    <Badge variant={getRoleColor(user.role)} className="mt-2 md:mt-0">
                      {getRoleName(user.role)}
                    </Badge>
                  </div>

                  <div className="mt-6">
                    <h3 className="text-lg font-semibold mb-2">Permissões:</h3>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className={`h-5 w-5 mr-2 ${user.role !== ROLES.VISITANTE ? "text-green-500" : "text-red-500"}`}
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          {user.role !== ROLES.VISITANTE ? (
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          ) : (
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M6 18L18 6M6 6l12 12"
                            />
                          )}
                        </svg>
                        <span>Criar e editar conteúdo</span>
                      </div>

                      <div className="flex items-center">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-5 w-5 mr-2 text-green-500"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        <span>Visualizar conteúdo</span>
                      </div>

                      <div className="flex items-center">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className={`h-5 w-5 mr-2 ${user.role === ROLES.ADMIN ? "text-green-500" : "text-red-500"}`}
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          {user.role === ROLES.ADMIN ? (
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          ) : (
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M6 18L18 6M6 6l12 12"
                            />
                          )}
                        </svg>
                        <span>Funções administrativas</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 flex flex-col space-y-3 sm:flex-row sm:space-y-0 sm:space-x-3">
                    <Button variant="outline">Editar Perfil</Button>
                    <Button variant="outline" onClick={handleLogout}>
                      Sair
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}
