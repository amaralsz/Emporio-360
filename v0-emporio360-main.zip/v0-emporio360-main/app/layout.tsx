import type React from "react"
import "../src/index.css"
import { Inter, Poppins } from "next/font/google"
import { AuthProvider } from "../src/contexts/AuthContext"

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
})

const poppins = Poppins({
  weight: ["400", "500", "600", "700"],
  subsets: ["latin"],
  display: "swap",
  variable: "--font-poppins",
})

export const metadata = {
  title: "Empório 360 - Conhecimento em todas as direções",
  description:
    "Plataforma moderna de troca de conhecimento, onde usuários podem compartilhar cursos, serviços, eventos, vagas de emprego e lojas.",
    generator: 'v0.dev'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" className={`${inter.variable} ${poppins.variable}`}>
      <body className="bg-background text-text">
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  )
}
