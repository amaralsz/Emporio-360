"use client"

import Link from "next/link"
import Navbar from "../../src/components/layout/Navbar"
import Footer from "../../src/components/layout/Footer"
import Button from "../../src/components/ui/Button"
import Card from "../../src/components/ui/Card"
import Badge from "../../src/components/ui/Badge"
import { useAuth, ROLES } from "../../src/contexts/AuthContext"

export default function CursosPage() {
  // Dados de exemplo
  const cursos = [
    {
      id: 1,
      titulo: "Desenvolvimento Web Completo",
      instrutor: "João Silva",
      preco: "R$ 199,90",
      avaliacao: 4.8,
      categoria: "Programação",
      imagem:
        "https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    },
    {
      id: 2,
      titulo: "Marketing Digital para Iniciantes",
      instrutor: "Maria Oliveira",
      preco: "R$ 149,90",
      avaliacao: 4.6,
      categoria: "Marketing",
      imagem:
        "https://images.unsplash.com/photo-1557838923-2985c318be48?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    },
    {
      id: 3,
      titulo: "Finanças Pessoais",
      instrutor: "Carlos Mendes",
      preco: "R$ 129,90",
      avaliacao: 4.9,
      categoria: "Finanças",
      imagem:
        "https://images.unsplash.com/photo-1554224155-6726b3ff858f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    },
    {
      id: 4,
      titulo: "Design de Interfaces Modernas",
      instrutor: "Ana Souza",
      preco: "R$ 179,90",
      avaliacao: 4.7,
      categoria: "Design",
      imagem:
        "https://images.unsplash.com/photo-1559028012-481c04fa702d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    },
  ]

  const { user, isAuthenticated } = useAuth()
  const canCreateContent = isAuthenticated && user.role !== ROLES.VISITANTE

  return (
    <>
      <Navbar />
      <main className="min-h-screen py-12 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">
                <span className="gold-gradient-text">Cursos</span>
              </h1>
              <p className="text-text-muted">Explore cursos em diversas áreas do conhecimento.</p>
            </div>
            {canCreateContent ? (
              <Link href="/criar/curso" className="mt-4 md:mt-0">
                <Button className="flex items-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5 mr-2"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                  Criar Curso
                </Button>
              </Link>
            ) : (
              isAuthenticated && (
                <div className="mt-4 md:mt-0 text-text-muted text-sm">
                  Você está logado como visitante e não pode criar cursos.
                </div>
              )
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {cursos.map((curso) => (
              <Card key={curso.id} hover className="overflow-hidden">
                <div className="relative h-48 mb-4">
                  <img
                    src={curso.imagem || "/placeholder.svg"}
                    alt={curso.titulo}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 right-2">
                    <Badge variant="primary">{curso.categoria}</Badge>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold mb-2 text-text">{curso.titulo}</h3>
                  <p className="text-text-muted text-sm mb-3">Por {curso.instrutor}</p>

                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4 text-primary"
                        fill="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279-7.416-3.967-7.417 3.967 1.481-8.279-6.064-5.828 8.332-1.151z" />
                      </svg>
                      <span className="text-text-muted text-sm ml-1">{curso.avaliacao}</span>
                    </div>
                    <span className="text-primary font-semibold">{curso.preco}</span>
                  </div>

                  <Button className="w-full mt-4">Ver Detalhes</Button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
