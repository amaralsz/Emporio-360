"use client"

import Link from "next/link"
import Navbar from "../../src/components/layout/Navbar"
import Footer from "../../src/components/layout/Footer"
import Button from "../../src/components/ui/Button"
import Card from "../../src/components/ui/Card"

export default function AccessDeniedPage() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen py-12 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-md mx-auto text-center">
            <Card className="p-8">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-16 w-16 text-primary mx-auto mb-4"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 15v2m0 0v2m0-2h2m-2 0H9m3-3V8m0 0V6m0 2h2M9 8h2m9 3a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>

              <h1 className="text-2xl font-bold mb-4">
                <span className="gold-gradient-text">Acesso Negado</span>
              </h1>

              <p className="text-text-muted mb-6">
                Você não tem permissão para acessar esta página. Esta funcionalidade está disponível apenas para
                usuários cadastradores.
              </p>

              <div className="space-y-3">
                <Link href="/">
                  <Button className="w-full">Voltar para a Página Inicial</Button>
                </Link>

                <Link href="/auth/login">
                  <Button variant="outline" className="w-full">
                    Fazer Login com Outra Conta
                  </Button>
                </Link>
              </div>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
