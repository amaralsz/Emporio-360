"use client"

import Link from "next/link"
import Navbar from "../../src/components/layout/Navbar"
import Footer from "../../src/components/layout/Footer"
import Button from "../../src/components/ui/Button"
import Card from "../../src/components/ui/Card"
import Badge from "../../src/components/ui/Badge"
import { useAuth, ROLES } from "../../src/contexts/AuthContext"

export default function ServicosPage() {
  // Dados de exemplo
  const servicos = [
    {
      id: 1,
      titulo: "Design de Logotipos Profissionais",
      prestador: "Ana Souza",
      preco: "R$ 500 por projeto",
      avaliacao: 4.9,
      categoria: "Design",
      disponibilidade: "Remoto",
      imagem:
        "https://images.unsplash.com/photo-1626785774573-4b799315345d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    },
    {
      id: 2,
      titulo: "Desenvolvimento de Sites Responsivos",
      prestador: "Carlos Mendes",
      preco: "A partir de R$ 2.000",
      avaliacao: 4.7,
      categoria: "Desenvolvimento",
      disponibilidade: "Remoto",
      imagem:
        "https://images.unsplash.com/photo-1547658719-da2b51169166?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    },
    {
      id: 3,
      titulo: "Consultoria em Marketing Digital",
      prestador: "Maria Oliveira",
      preco: "R$ 150 por hora",
      avaliacao: 4.8,
      categoria: "Marketing",
      disponibilidade: "Ambos",
      imagem:
        "https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    },
    {
      id: 4,
      titulo: "Aulas de Inglês Particulares",
      prestador: "João Silva",
      preco: "R$ 80 por hora",
      avaliacao: 4.6,
      categoria: "Educação",
      disponibilidade: "Ambos",
      imagem:
        "https://images.unsplash.com/photo-1503428593586-e225b39bddfe?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    },
  ]

  const { user, isAuthenticated } = useAuth()
  const canCreateContent = isAuthenticated && user.role !== ROLES.VISITANTE

  return (
    <>
      <Navbar />
      <main className="min-h-screen py-12 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">
                <span className="gold-gradient-text">Serviços</span>
              </h1>
              <p className="text-text-muted">Encontre profissionais qualificados para diversos serviços.</p>
            </div>
            {canCreateContent ? (
              <Link href="/criar/servico" className="mt-4 md:mt-0">
                <Button className="flex items-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5 mr-2"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                  Oferecer Serviço
                </Button>
              </Link>
            ) : (
              isAuthenticated && (
                <div className="mt-4 md:mt-0 text-text-muted text-sm">
                  Você está logado como visitante e não pode oferecer serviços.
                </div>
              )
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {servicos.map((servico) => (
              <Card key={servico.id} hover className="overflow-hidden">
                <div className="flex flex-col md:flex-row">
                  <div className="md:w-1/3 h-48 md:h-auto">
                    <img
                      src={servico.imagem || "/placeholder.svg"}
                      alt={servico.titulo}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="md:w-2/3 p-6">
                    <div className="flex flex-wrap gap-2 mb-3">
                      <Badge variant="primary">{servico.categoria}</Badge>
                      <Badge variant="outline">{servico.disponibilidade}</Badge>
                    </div>

                    <h3 className="text-xl font-semibold mb-2 text-text">{servico.titulo}</h3>
                    <p className="text-text-muted text-sm mb-3">Por {servico.prestador}</p>

                    <div className="flex justify-between items-center mb-4">
                      <div className="flex items-center">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-4 w-4 text-primary"
                          fill="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279-7.416-3.967-7.417 3.967 1.481-8.279-6.064-5.828 8.332-1.151z" />
                        </svg>
                        <span className="text-text-muted text-sm ml-1">{servico.avaliacao}</span>
                      </div>
                      <span className="text-primary font-semibold">{servico.preco}</span>
                    </div>

                    <Button>Contratar</Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
