"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Navbar from "../../../src/components/layout/Navbar"
import Footer from "../../../src/components/layout/Footer"
import Form from "../../../src/components/ui/Form"
import FormField from "../../../src/components/ui/FormField"
import TextArea from "../../../src/components/ui/TextArea"
import Select from "../../../src/components/ui/Select"
import ImageUpload from "../../../src/components/ui/ImageUpload"
import Button from "../../../src/components/ui/Button"
import Card from "../../../src/components/ui/Card"
import { useAuth, ROLES } from "../../../src/contexts/AuthContext"

const categorias = [
  { value: "workshop", label: "Workshop" },
  { value: "conferencia", label: "Conferência" },
  { value: "meetup", label: "Meetup" },
  { value: "webinar", label: "Webinar" },
  { value: "curso", label: "Curso Presencial" },
  { value: "feira", label: "Feira" },
]

const modalidades = [
  { value: "presencial", label: "Presencial" },
  { value: "online", label: "Online" },
  { value: "hibrido", label: "Híbrido" },
]

export default function CriarEventoPage() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [imagem, setImagem] = useState(null)
  const { user, isAuthenticated } = useAuth()

  // Verificar se o usuário tem permissão para acessar esta página
  useEffect(() => {
    // Redireciona para login se não estiver autenticado
    if (!isAuthenticated) {
      router.push("/auth/login")
      return
    }

    // Verifica se o usuário tem permissão para criar conteúdo
    if (user.role === ROLES.VISITANTE) {
      alert("Você não tem permissão para criar eventos. Apenas usuários cadastradores podem criar conteúdo.")
      router.push("/")
    }
  }, [isAuthenticated, user, router])

  // Se não estiver autenticado ou não tiver permissão, não renderiza o conteúdo
  if (!isAuthenticated || user.role === ROLES.VISITANTE) {
    return null
  }

  const handleSubmit = async (e) => {
    setIsSubmitting(true)

    // Simulando envio para API
    const formData = new FormData(e.target)
    const data = Object.fromEntries(formData.entries())

    // Adicionar imagem
    if (imagem) {
      data.imagem = imagem
    }

    console.log("Dados do evento:", data)

    // Simulando delay de API
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsSubmitting(false)

    // Redirecionar para página de sucesso
    alert("Evento criado com sucesso!")
    router.push("/eventos")
  }

  const handleImageChange = (file) => {
    setImagem(file)
  }

  return (
    <>
      <Navbar />
      <main className="min-h-screen py-12 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold mb-2">
                <span className="gold-gradient-text">Criar Novo Evento</span>
              </h1>
              <p className="text-text-muted">
                Compartilhe conhecimento organizando um evento na plataforma Empório 360.
              </p>
            </div>

            <Card className="p-6">
              <Form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="md:col-span-2">
                    <FormField
                      label="Nome do Evento"
                      id="nome"
                      placeholder="Ex: Workshop de Design Thinking"
                      required
                    />
                  </div>

                  <div className="md:col-span-2">
                    <FormField label="Descrição" id="descricao" required>
                      <TextArea id="descricao" placeholder="Descreva o seu evento..." rows={5} required />
                    </FormField>
                  </div>

                  <FormField label="Categoria" id="categoria" required>
                    <Select id="categoria" options={categorias} required />
                  </FormField>

                  <FormField label="Modalidade" id="modalidade" required>
                    <Select id="modalidade" options={modalidades} required />
                  </FormField>

                  <FormField label="Data" id="data" type="date" required />

                  <FormField label="Horário" id="horario" type="time" required />

                  <FormField
                    label="Local/Endereço"
                    id="local"
                    placeholder="Ex: Av. Paulista, 1000 - São Paulo, SP"
                    required
                  />

                  <FormField
                    label="Preço (R$)"
                    id="preco"
                    type="number"
                    placeholder="0 para eventos gratuitos"
                    required
                  />

                  <div className="md:col-span-2">
                    <ImageUpload id="imagem" label="Imagem do Evento" onChange={handleImageChange} />
                  </div>

                  <div className="md:col-span-2">
                    <FormField label="Programação" id="programacao" required>
                      <TextArea id="programacao" placeholder="Descreva a programação do evento..." rows={8} required />
                    </FormField>
                  </div>
                </div>

                <div className="flex justify-end space-x-4 mt-8">
                  <Link href="/eventos">
                    <Button variant="outline" type="button">
                      Cancelar
                    </Button>
                  </Link>
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? "Criando..." : "Criar Evento"}
                  </Button>
                </div>
              </Form>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
