"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Navbar from "../../../src/components/layout/Navbar"
import Footer from "../../../src/components/layout/Footer"
import Form from "../../../src/components/ui/Form"
import FormField from "../../../src/components/ui/FormField"
import TextArea from "../../../src/components/ui/TextArea"
import Select from "../../../src/components/ui/Select"
import ImageUpload from "../../../src/components/ui/ImageUpload"
import Button from "../../../src/components/ui/Button"
import Card from "../../../src/components/ui/Card"
import { useAuth, ROLES } from "../../../src/contexts/AuthContext"

const categorias = [
  { value: "programacao", label: "Programação" },
  { value: "design", label: "Design" },
  { value: "marketing", label: "Marketing" },
  { value: "negocios", label: "Negócios" },
  { value: "financas", label: "Finanças" },
  { value: "desenvolvimento-pessoal", label: "Desenvolvimento Pessoal" },
]

const niveis = [
  { value: "iniciante", label: "Iniciante" },
  { value: "intermediario", label: "Intermediário" },
  { value: "avancado", label: "Avançado" },
  { value: "todos", label: "Todos os níveis" },
]

export default function CriarCursoPage() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [imagem, setImagem] = useState(null)
  const { user, isAuthenticated } = useAuth()

  // Verificar se o usuário tem permissão para acessar esta página
  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/auth/login")
      return
    }

    // Verificar se o usuário tem permissão para criar conteúdo
    if (user.role === ROLES.VISITANTE) {
      alert("Você não tem permissão para criar cursos. Apenas usuários cadastradores podem criar conteúdo.")
      router.push("/")
    }
  }, [isAuthenticated, user, router])

  // Se o usuário não está autenticado ou não tem permissão, não renderiza nada
  if (!isAuthenticated || user.role === ROLES.VISITANTE) {
    return null
  }

  const handleSubmit = async (e) => {
    setIsSubmitting(true)

    // Simulando envio para API
    const formData = new FormData(e.target)
    const data = Object.fromEntries(formData.entries())

    // Adicionar imagem
    if (imagem) {
      data.imagem = imagem
    }

    console.log("Dados do curso:", data)

    // Simulando delay de API
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsSubmitting(false)

    // Redirecionar para página de sucesso
    alert("Curso criado com sucesso!")
    router.push("/cursos")
  }

  const handleImageChange = (file) => {
    setImagem(file)
  }

  return (
    <>
      <Navbar />
      <main className="min-h-screen py-12 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold mb-2">
                <span className="gold-gradient-text">Criar Novo Curso</span>
              </h1>
              <p className="text-text-muted">
                Compartilhe seu conhecimento criando um curso na plataforma Empório 360.
              </p>
            </div>

            <Card className="p-6">
              <Form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="md:col-span-2">
                    <FormField
                      label="Título do Curso"
                      id="titulo"
                      placeholder="Ex: Desenvolvimento Web Completo"
                      required
                    />
                  </div>

                  <div className="md:col-span-2">
                    <FormField label="Descrição" id="descricao" required>
                      <TextArea id="descricao" placeholder="Descreva o conteúdo do seu curso..." rows={5} required />
                    </FormField>
                  </div>

                  <FormField label="Categoria" id="categoria" required>
                    <Select id="categoria" options={categorias} required />
                  </FormField>

                  <FormField label="Nível" id="nivel" required>
                    <Select id="nivel" options={niveis} required />
                  </FormField>

                  <FormField label="Preço (R$)" id="preco" type="number" placeholder="99.90" required />

                  <FormField label="Duração (horas)" id="duracao" type="number" placeholder="10" required />

                  <div className="md:col-span-2">
                    <ImageUpload id="imagem" label="Imagem de Capa" onChange={handleImageChange} />
                  </div>

                  <div className="md:col-span-2">
                    <FormField label="Conteúdo do Curso" id="conteudo" required>
                      <TextArea
                        id="conteudo"
                        placeholder="Liste os tópicos que serão abordados no curso..."
                        rows={8}
                        required
                      />
                    </FormField>
                  </div>
                </div>

                <div className="flex justify-end space-x-4 mt-8">
                  <Link href="/cursos">
                    <Button variant="outline" type="button">
                      Cancelar
                    </Button>
                  </Link>
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? "Criando..." : "Criar Curso"}
                  </Button>
                </div>
              </Form>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
