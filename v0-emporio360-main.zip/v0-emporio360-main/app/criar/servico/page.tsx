"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Navbar from "../../../src/components/layout/Navbar"
import Footer from "../../../src/components/layout/Footer"
import Form from "../../../src/components/ui/Form"
import FormField from "../../../src/components/ui/FormField"
import TextArea from "../../../src/components/ui/TextArea"
import Select from "../../../src/components/ui/Select"
import ImageUpload from "../../../src/components/ui/ImageUpload"
import Button from "../../../src/components/ui/Button"
import Card from "../../../src/components/ui/Card"
import { useAuth, ROLES } from "../../../src/contexts/AuthContext"

const categorias = [
  { value: "design", label: "Design" },
  { value: "desenvolvimento", label: "Desenvolvimento" },
  { value: "marketing", label: "Marketing" },
  { value: "consultoria", label: "Consultoria" },
  { value: "educacao", label: "Educação" },
  { value: "saude", label: "Saúde" },
  { value: "outros", label: "Outros" },
]

const disponibilidades = [
  { value: "remoto", label: "Remoto" },
  { value: "presencial", label: "Presencial" },
  { value: "ambos", label: "Ambos" },
]

export default function CriarServicoPage() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [imagem, setImagem] = useState(null)
  const { user, isAuthenticated } = useAuth()

  useEffect(() => {
    // Redireciona para login se não estiver autenticado
    if (!isAuthenticated) {
      router.push("/auth/login")
      return
    }

    // Verifica se o usuário tem permissão para criar conteúdo
    if (user.role === ROLES.VISITANTE) {
      alert("Você não tem permissão para criar serviços. Apenas usuários cadastradores podem criar conteúdo.")
      router.push("/")
    }
  }, [isAuthenticated, user, router])

  // Se não estiver autenticado ou não tiver permissão, não renderiza o conteúdo
  if (!isAuthenticated || user.role === ROLES.VISITANTE) {
    return null
  }

  const handleSubmit = async (e) => {
    setIsSubmitting(true)

    // Simulando envio para API
    const formData = new FormData(e.target)
    const data = Object.fromEntries(formData.entries())

    // Adicionar imagem
    if (imagem) {
      data.imagem = imagem
    }

    console.log("Dados do serviço:", data)

    // Simulando delay de API
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsSubmitting(false)

    // Redirecionar para página de sucesso
    alert("Serviço criado com sucesso!")
    router.push("/servicos")
  }

  const handleImageChange = (file) => {
    setImagem(file)
  }

  return (
    <>
      <Navbar />
      <main className="min-h-screen py-12 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold mb-2">
                <span className="gold-gradient-text">Criar Novo Serviço</span>
              </h1>
              <p className="text-text-muted">Ofereça seus serviços e habilidades na plataforma Empório 360.</p>
            </div>

            <Card className="p-6">
              <Form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="md:col-span-2">
                    <FormField
                      label="Título do Serviço"
                      id="titulo"
                      placeholder="Ex: Design de Logotipos Profissionais"
                      required
                    />
                  </div>

                  <div className="md:col-span-2">
                    <FormField label="Descrição" id="descricao" required>
                      <TextArea id="descricao" placeholder="Descreva o serviço que você oferece..." rows={5} required />
                    </FormField>
                  </div>

                  <FormField label="Categoria" id="categoria" required>
                    <Select id="categoria" options={categorias} required />
                  </FormField>

                  <FormField label="Disponibilidade" id="disponibilidade" required>
                    <Select id="disponibilidade" options={disponibilidades} required />
                  </FormField>

                  <FormField
                    label="Preço (R$)"
                    id="preco"
                    type="text"
                    placeholder="Ex: 100 por hora ou 500 por projeto"
                    required
                  />

                  <FormField label="Prazo de Entrega" id="prazo" placeholder="Ex: 5 dias úteis" required />

                  <div className="md:col-span-2">
                    <ImageUpload id="imagem" label="Imagem do Serviço" onChange={handleImageChange} />
                  </div>

                  <div className="md:col-span-2">
                    <FormField label="Habilidades" id="habilidades" required>
                      <TextArea
                        id="habilidades"
                        placeholder="Liste suas habilidades relevantes para este serviço..."
                        rows={3}
                        required
                      />
                    </FormField>
                  </div>

                  <div className="md:col-span-2">
                    <FormField label="Experiência" id="experiencia">
                      <TextArea id="experiencia" placeholder="Descreva sua experiência nesta área..." rows={3} />
                    </FormField>
                  </div>
                </div>

                <div className="flex justify-end space-x-4 mt-8">
                  <Link href="/servicos">
                    <Button variant="outline" type="button">
                      Cancelar
                    </Button>
                  </Link>
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? "Criando..." : "Criar Serviço"}
                  </Button>
                </div>
              </Form>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
