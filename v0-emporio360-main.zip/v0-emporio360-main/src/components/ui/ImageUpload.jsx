"use client"

import { useState, useRef } from "react"
import PropTypes from "prop-types"

const ImageUpload = ({ id, label, onChange, className = "" }) => {
  const [preview, setPreview] = useState(null)
  const fileInputRef = useRef(null)

  const handleFileChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setPreview(reader.result)
      }
      reader.readAsDataURL(file)
      onChange(file)
    }
  }

  const handleClick = () => {
    fileInputRef.current.click()
  }

  return (
    <div className={`space-y-3 ${className}`}>
      <label className="block text-sm font-medium text-text">{label}</label>

      <div
        className="border-2 border-dashed border-primary/30 rounded-lg p-4 text-center hover:border-primary/60 transition-colors cursor-pointer"
        onClick={handleClick}
      >
        {preview ? (
          <div className="relative">
            <img src={preview || "/placeholder.svg"} alt="Preview" className="mx-auto max-h-48 rounded-md" />
            <div className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 hover:opacity-100 transition-opacity rounded-md">
              <p className="text-white text-sm">Clique para alterar</p>
            </div>
          </div>
        ) : (
          <div className="py-8">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-12 w-12 mx-auto text-primary/50"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
              />
            </svg>
            <p className="mt-2 text-sm text-text-muted">Clique para fazer upload de uma imagem</p>
            <p className="text-xs text-text-muted mt-1">PNG, JPG ou GIF até 5MB</p>
          </div>
        )}

        <input
          type="file"
          id={id}
          name={id}
          ref={fileInputRef}
          onChange={handleFileChange}
          accept="image/*"
          className="hidden"
        />
      </div>
    </div>
  )
}

ImageUpload.propTypes = {
  id: PropTypes.string.isRequired,
  label: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
  className: PropTypes.string,
}

export default ImageUpload
