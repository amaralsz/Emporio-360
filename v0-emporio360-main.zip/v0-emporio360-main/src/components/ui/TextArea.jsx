"use client"

import PropTypes from "prop-types"

const TextArea = ({ id, rows = 4, className = "", ...props }) => {
  return (
    <textarea
      id={id}
      name={id}
      rows={rows}
      className={`w-full bg-background-light border border-primary/30 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 text-text resize-none ${className}`}
      {...props}
    />
  )
}

TextArea.propTypes = {
  id: PropTypes.string.isRequired,
  rows: PropTypes.number,
  className: PropTypes.string,
}

export default TextArea
