import PropTypes from "prop-types"

const Avatar = ({ src, alt, size = "md", className = "", ...props }) => {
  const baseClasses = "rounded-full overflow-hidden bg-background-light border border-primary/20"

  const sizeClasses = {
    xs: "w-6 h-6",
    sm: "w-8 h-8",
    md: "w-10 h-10",
    lg: "w-12 h-12",
    xl: "w-16 h-16",
  }

  return (
    <div className={`${baseClasses} ${sizeClasses[size]} ${className}`} {...props}>
      {src ? (
        <img src={src || "/placeholder.svg"} alt={alt || "Avatar"} className="w-full h-full object-cover" />
      ) : (
        <div className="w-full h-full flex items-center justify-center bg-primary/10 text-primary">
          {alt ? alt.charAt(0).toUpperCase() : "U"}
        </div>
      )}
    </div>
  )
}

Avatar.propTypes = {
  src: PropTypes.string,
  alt: PropTypes.string,
  size: PropTypes.oneOf(["xs", "sm", "md", "lg", "xl"]),
  className: PropTypes.string,
}

export default Avatar
