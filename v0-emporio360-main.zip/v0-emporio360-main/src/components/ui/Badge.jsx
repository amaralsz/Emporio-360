import PropTypes from "prop-types"

const Badge = ({ children, variant = "default", size = "md", className = "", ...props }) => {
  const baseClasses = "inline-flex items-center justify-center font-medium rounded-full"

  const variantClasses = {
    default: "bg-primary/20 text-primary",
    primary: "bg-primary text-background",
    secondary: "bg-background-light text-text border border-primary/30",
    outline: "bg-transparent border border-primary text-primary",
    success: "bg-green-500/20 text-green-500",
    warning: "bg-yellow-500/20 text-yellow-500",
    danger: "bg-red-500/20 text-red-500",
  }

  const sizeClasses = {
    sm: "text-xs px-2 py-0.5",
    md: "text-sm px-2.5 py-0.5",
    lg: "px-3 py-1",
  }

  return (
    <span className={`${baseClasses} ${variantClasses[variant]} ${sizeClasses[size]} ${className}`} {...props}>
      {children}
    </span>
  )
}

Badge.propTypes = {
  children: PropTypes.node.isRequired,
  variant: PropTypes.oneOf(["default", "primary", "secondary", "outline", "success", "warning", "danger"]),
  size: PropTypes.oneOf(["sm", "md", "lg"]),
  className: PropTypes.string,
}

export default Badge
