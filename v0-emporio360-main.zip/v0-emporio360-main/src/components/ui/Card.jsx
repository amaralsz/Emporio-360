import PropTypes from "prop-types"

const Card = ({ children, className = "", variant = "default", hover = false, ...props }) => {
  const baseClasses = "rounded-lg p-4"

  const variantClasses = {
    default: "bg-background-light border border-primary/20",
    elevated: "bg-background-light border border-primary/20 shadow-md",
    outlined: "bg-transparent border border-primary/40",
    feature: "bg-gradient-to-br from-background to-background-light border border-primary/30",
  }

  const hoverClasses = hover
    ? "transition-all duration-300 hover:border-primary/60 hover:shadow-lg hover:shadow-primary/10"
    : ""

  return (
    <div className={`${baseClasses} ${variantClasses[variant]} ${hoverClasses} ${className}`} {...props}>
      {children}
    </div>
  )
}

Card.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
  variant: PropTypes.oneOf(["default", "elevated", "outlined", "feature"]),
  hover: PropTypes.bool,
}

export default Card
