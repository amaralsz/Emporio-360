"use client"

import PropTypes from "prop-types"

const FormField = ({
  label,
  id,
  type = "text",
  placeholder,
  required = false,
  error,
  className = "",
  children,
  ...props
}) => {
  return (
    <div className={`space-y-2 ${className}`}>
      <label htmlFor={id} className="block text-sm font-medium text-text">
        {label} {required && <span className="text-primary">*</span>}
      </label>

      {children ? (
        children
      ) : (
        <input
          type={type}
          id={id}
          name={id}
          placeholder={placeholder}
          required={required}
          className="w-full bg-background-light border border-primary/30 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 text-text"
          {...props}
        />
      )}

      {error && <p className="text-red-500 text-sm">{error}</p>}
    </div>
  )
}

FormField.propTypes = {
  label: PropTypes.string.isRequired,
  id: PropTypes.string.isRequired,
  type: PropTypes.string,
  placeholder: PropTypes.string,
  required: PropTypes.bool,
  error: PropTypes.string,
  className: PropTypes.string,
  children: PropTypes.node,
}

export default FormField
