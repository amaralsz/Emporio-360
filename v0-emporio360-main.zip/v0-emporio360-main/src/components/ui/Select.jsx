"use client"

import PropTypes from "prop-types"

const Select = ({ id, options, className = "", ...props }) => {
  return (
    <select
      id={id}
      name={id}
      className={`w-full bg-background-light border border-primary/30 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 text-text ${className}`}
      {...props}
    >
      {options.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  )
}

Select.propTypes = {
  id: PropTypes.string.isRequired,
  options: PropTypes.arrayOf(
    PropTypes.shape({
      value: PropTypes.string.isRequired,
      label: PropTypes.string.isRequired,
    }),
  ).isRequired,
  className: PropTypes.string,
}

export default Select
