"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth, ROLES } from "../../contexts/AuthContext"

const RequireAuth = ({ children, requiredRole = ROLES.VISITANTE }) => {
  const { user, isAuthenticated } = useAuth()
  const router = useRouter()

  useEffect(() => {
    // Se o usuário não estiver autenticado, redireciona para o login
    if (!isAuthenticated) {
      router.push("/auth/login")
      return
    }

    // Verificação de permissões
    let hasPermission = false

    switch (requiredRole) {
      case ROLES.ADMIN:
        hasPermission = user.role === ROLES.ADMIN
        break
      case ROLES.CADASTRADOR:
        hasPermission = user.role === ROLES.ADMIN || user.role === ROLES.CADASTRADOR
        break
      case ROLES.VISITANTE:
        hasPermission = true // Todos os usuários autenticados podem acessar
        break
      default:
        hasPermission = false
    }

    if (!hasPermission) {
      router.push("/")
    }
  }, [isAuthenticated, user, requiredRole, router])

  // Se o usuário não estiver autenticado ou não tiver permissão, não renderiza nada
  if (!isAuthenticated) {
    return null
  }

  return children
}

export default RequireAuth
