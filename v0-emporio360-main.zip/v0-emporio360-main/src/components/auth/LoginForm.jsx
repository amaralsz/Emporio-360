"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Button from "../ui/Button"
import Card from "../ui/Card"
import FormField from "../ui/FormField"
import { useAuth } from "../../contexts/AuthContext"

const LoginForm = () => {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const { login } = useAuth()
  const router = useRouter()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    // Validação básica
    if (!email || !password) {
      setError("Por favor, preencha todos os campos")
      setIsLoading(false)
      return
    }

    // Simulando uma chamada de API
    setTimeout(() => {
      const result = login(email, password)
      if (result.success) {
        router.push("/")
      } else {
        setError(result.error || "Erro ao fazer login")
      }
      setIsLoading(false)
    }, 1000)
  }

  return (
    <Card className="w-full max-w-md p-6">
      <h2 className="text-2xl font-bold mb-6 text-center">
        <span className="gold-gradient-text">Entrar na Plataforma</span>
      </h2>

      {error && <div className="bg-red-500/20 text-red-500 p-3 rounded-md mb-4">{error}</div>}

      <form onSubmit={handleSubmit} className="space-y-4">
        <FormField
          label="Email"
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Seu email"
          required
        />

        <FormField
          label="Senha"
          id="password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Sua senha"
          required
        />

        <div className="flex justify-between items-center">
          <label className="flex items-center space-x-2 text-sm text-text-muted">
            <input type="checkbox" className="rounded border-primary/30 focus:ring-primary" />
            <span>Lembrar-me</span>
          </label>

          <Link href="/auth/recuperar-senha" className="text-sm text-primary hover:text-primary-light">
            Esqueceu a senha?
          </Link>
        </div>

        <Button type="submit" className="w-full" disabled={isLoading}>
          {isLoading ? "Entrando..." : "Entrar"}
        </Button>
      </form>

      <div className="mt-6 text-center">
        <p className="text-text-muted">
          Não tem uma conta?{" "}
          <Link href="/auth/registrar" className="text-primary hover:text-primary-light">
            Registre-se
          </Link>
        </p>

        <div className="mt-4 text-sm text-text-muted">
          <p>Credenciais para teste:</p>
          <p>Admin: admin@example.com / senha123</p>
          <p>Usuário: user@example.com / senha123</p>
          <p>Visitante: visitante@example.com / senha123</p>
        </div>
      </div>
    </Card>
  )
}

export default LoginForm
