"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Button from "../ui/Button"
import Card from "../ui/Card"
import FormField from "../ui/FormField"
import { useAuth } from "../../contexts/AuthContext"

const RegisterForm = () => {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const { register } = useAuth()
  const router = useRouter()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    // Validação básica
    if (!name || !email || !password || !confirmPassword) {
      setError("Por favor, preencha todos os campos")
      setIsLoading(false)
      return
    }

    if (password !== confirmPassword) {
      setError("As senhas não coincidem")
      setIsLoading(false)
      return
    }

    // Simulando uma chamada de API
    setTimeout(() => {
      try {
        const result = register(name, email, password)
        if (result.success) {
          router.push("/")
        } else {
          setError(result.error || "Erro ao registrar")
        }
      } catch (err) {
        setError("Ocorreu um erro ao registrar. Tente novamente.")
      }
      setIsLoading(false)
    }, 1000)
  }

  return (
    <Card className="w-full max-w-md p-6">
      <h2 className="text-2xl font-bold mb-6 text-center">
        <span className="gold-gradient-text">Criar Conta</span>
      </h2>

      {error && <div className="bg-red-500/20 text-red-500 p-3 rounded-md mb-4">{error}</div>}

      <form onSubmit={handleSubmit} className="space-y-4">
        <FormField
          label="Nome completo"
          id="name"
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Seu nome"
          required
        />

        <FormField
          label="Email"
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Seu email"
          required
        />

        <FormField
          label="Senha"
          id="password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Sua senha"
          required
        />

        <FormField
          label="Confirme a senha"
          id="confirmPassword"
          type="password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          placeholder="Confirme sua senha"
          required
        />

        <div className="flex items-center space-x-2 text-sm text-text-muted">
          <input type="checkbox" id="terms" className="rounded border-primary/30 focus:ring-primary" required />
          <label htmlFor="terms">
            Concordo com os{" "}
            <Link href="/termos" className="text-primary hover:text-primary-light">
              Termos de Uso
            </Link>{" "}
            e{" "}
            <Link href="/privacidade" className="text-primary hover:text-primary-light">
              Política de Privacidade
            </Link>
          </label>
        </div>

        <Button type="submit" className="w-full" disabled={isLoading}>
          {isLoading ? "Registrando..." : "Registrar"}
        </Button>
      </form>

      <div className="mt-6 text-center">
        <p className="text-text-muted">
          Já tem uma conta?{" "}
          <Link href="/auth/login" className="text-primary hover:text-primary-light">
            Fazer login
          </Link>
        </p>
      </div>
    </Card>
  )
}

export default RegisterForm
