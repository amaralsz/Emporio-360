"use client"

import { createContext, useContext, useState, useEffect } from "react"

// Define os tipos de usuário
export const ROLES = {
  VISITANTE: "visitante",
  CADASTRADOR: "cadastrador",
  ADMIN: "admin",
}

// Interface para o usuário
export const defaultUser = {
  id: "",
  name: "",
  email: "",
  avatar: "",
  role: ROLES.VISITANTE,
}

// Criar o contexto
export const AuthContext = createContext({
  user: defaultUser,
  isAuthenticated: false,
  login: (email, password) => {},
  register: (name, email, password) => {},
  logout: () => {},
})

export function AuthProvider({ children }) {
  const [user, setUser] = useState(defaultUser)
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  // Verificar se o usuário já está autenticado ao carregar a página
  useEffect(() => {
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser)
      setUser(parsedUser)
      setIsAuthenticated(true)
    }
  }, [])

  // Função de login
  const login = (email, password) => {
    // Em um sistema real, aqui faria uma chamada à API
    // Simulando uma autenticação básica
    if (email === "admin@example.com" && password === "senha123") {
      const adminUser = {
        id: "1",
        name: "Administrador",
        email: "admin@example.com",
        avatar: "/placeholder.svg?height=80&width=80",
        role: ROLES.ADMIN,
      }
      setUser(adminUser)
      setIsAuthenticated(true)
      localStorage.setItem("user", JSON.stringify(adminUser))
      return { success: true }
    } else if (email === "user@example.com" && password === "senha123") {
      const normalUser = {
        id: "2",
        name: "Usuário Cadastrador",
        email: "user@example.com",
        avatar: "/placeholder.svg?height=80&width=80",
        role: ROLES.CADASTRADOR,
      }
      setUser(normalUser)
      setIsAuthenticated(true)
      localStorage.setItem("user", JSON.stringify(normalUser))
      return { success: true }
    } else if (email === "visitante@example.com" && password === "senha123") {
      const visitorUser = {
        id: "3",
        name: "Visitante",
        email: "visitante@example.com",
        avatar: "/placeholder.svg?height=80&width=80",
        role: ROLES.VISITANTE,
      }
      setUser(visitorUser)
      setIsAuthenticated(true)
      localStorage.setItem("user", JSON.stringify(visitorUser))
      return { success: true }
    }

    return { success: false, error: "Email ou senha inválidos" }
  }

  // Função de registro
  const register = (name, email, password) => {
    // Em um sistema real, aqui faria uma chamada à API
    // Simulando um registro básico
    const newUser = {
      id: Math.random().toString(36).substring(2, 9),
      name,
      email,
      avatar: "/placeholder.svg?height=80&width=80",
      role: ROLES.CADASTRADOR, // Por padrão, novos usuários são cadastradores
    }

    setUser(newUser)
    setIsAuthenticated(true)
    localStorage.setItem("user", JSON.stringify(newUser))
    return { success: true }
  }

  // Função de logout
  const logout = () => {
    setUser(defaultUser)
    setIsAuthenticated(false)
    localStorage.removeItem("user")
  }

  return (
    <AuthContext.Provider value={{ user, isAuthenticated, login, register, logout }}>{children}</AuthContext.Provider>
  )
}

// Hook personalizado para usar o contexto
export function useAuth() {
  return useContext(AuthContext)
}

// Hook para verificar permissões de usuário
export function useAuthorization(requiredRole = null) {
  const { user, isAuthenticated } = useAuth()

  if (!requiredRole) {
    return { isAuthorized: isAuthenticated }
  }

  if (requiredRole === ROLES.CADASTRADOR) {
    return {
      isAuthorized: isAuthenticated && (user.role === ROLES.CADASTRADOR || user.role === ROLES.ADMIN),
    }
  }

  if (requiredRole === ROLES.ADMIN) {
    return { isAuthorized: isAuthenticated && user.role === ROLES.ADMIN }
  }

  // Visitantes e todos os outros podem acessar conteúdo público
  return { isAuthorized: true }
}
