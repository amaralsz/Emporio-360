"use client"

import { useState } from "react"
import Link from "next/link"
import Button from "../ui/Button"
// Adicione o import para o hook useAuth
import { useAuth, ROLES } from "../contexts/AuthContext"

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isCreateMenuOpen, setIsCreateMenuOpen] = useState(false)
  const { user, isAuthenticated, logout } = useAuth()

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
    if (isCreateMenuOpen) setIsCreateMenuOpen(false)
  }

  const toggleCreateMenu = () => {
    setIsCreateMenuOpen(!isCreateMenuOpen)
  }

  const handleLogout = () => {
    logout()
  }

  // Verifica se o usuário pode criar conteúdo
  const canCreate = isAuthenticated && (user.role === ROLES.CADASTRADOR || user.role === ROLES.ADMIN)

  // Modificar a seção de User Actions para adicionar lógica de autenticação
  // Substitua a div "User Actions" pelo seguinte código:

  return (
    <nav className="bg-background-light border-b border-primary/20 py-3 px-4 sticky top-0 z-50">
      <div className="container mx-auto flex justify-between items-center">
        {/* Logo */}
        <Link href="/" className="flex items-center">
          <span className="text-2xl font-bold gold-gradient-text">Empório 360</span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-6">
          <Link href="/cursos" className="text-text hover:text-primary transition-colors">
            Cursos
          </Link>
          <Link href="/servicos" className="text-text hover:text-primary transition-colors">
            Serviços
          </Link>
          <Link href="/eventos" className="text-text hover:text-primary transition-colors">
            Eventos
          </Link>
          <Link href="/empregos" className="text-text hover:text-primary transition-colors">
            Empregos
          </Link>
          <Link href="/lojas" className="text-text hover:text-primary transition-colors">
            Lojas
          </Link>
          <Link href="/chat" className="text-text hover:text-primary transition-colors">
            Chat
          </Link>
        </div>

        {/* User Actions */}
        <div className="hidden md:flex items-center space-x-3">
          {/* Create Menu - Visível apenas para usuários com permissão */}
          {canCreate && (
            <div className="relative">
              <Button variant="outline" size="sm" onClick={toggleCreateMenu} className="flex items-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4 mr-1"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
                Criar
              </Button>

              {isCreateMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-background-light border border-primary/20 rounded-md shadow-lg py-1 z-50">
                  <Link
                    href="/criar/curso"
                    className="block px-4 py-2 text-text hover:bg-primary/10 hover:text-primary"
                    onClick={() => setIsCreateMenuOpen(false)}
                  >
                    <div className="flex items-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4 mr-2 text-primary"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
                        />
                      </svg>
                      Criar Curso
                    </div>
                  </Link>
                  <Link
                    href="/criar/evento"
                    className="block px-4 py-2 text-text hover:bg-primary/10 hover:text-primary"
                    onClick={() => setIsCreateMenuOpen(false)}
                  >
                    <div className="flex items-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4 mr-2 text-primary"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                        />
                      </svg>
                      Criar Evento
                    </div>
                  </Link>
                  <Link
                    href="/criar/servico"
                    className="block px-4 py-2 text-text hover:bg-primary/10 hover:text-primary"
                    onClick={() => setIsCreateMenuOpen(false)}
                  >
                    <div className="flex items-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4 mr-2 text-primary"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                        />
                      </svg>
                      Criar Serviço
                    </div>
                  </Link>
                </div>
              )}
            </div>
          )}

          {/* Mostrar botões de login/cadastro ou perfil/logout baseado no status de autenticação */}
          {!isAuthenticated ? (
            <>
              <Link href="/auth/login">
                <Button variant="outline" size="sm">
                  Entrar
                </Button>
              </Link>
              <Link href="/auth/registrar">
                <Button size="sm">Cadastrar</Button>
              </Link>
            </>
          ) : (
            <>
              <Link href="/perfil">
                <Button variant="outline" size="sm" className="flex items-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 mr-1"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                    />
                  </svg>
                  Perfil
                </Button>
              </Link>
              <Button size="sm" onClick={handleLogout}>
                Sair
              </Button>
            </>
          )}
        </div>

        {/* Mobile Menu Button */}
        <div className="flex md:hidden items-center space-x-2">
          {/* Mobile Create Button - Visível apenas para usuários com permissão */}
          {canCreate && (
            <button
              className="text-text hover:text-primary p-1"
              onClick={toggleCreateMenu}
              aria-label="Toggle create menu"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
            </button>
          )}

          {/* Mobile Menu Button */}
          <button className="text-text hover:text-primary p-1" onClick={toggleMenu} aria-label="Toggle menu">
            {isMenuOpen ? (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            ) : (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            )}
          </button>
        </div>
      </div>

      {/* Mobile Create Menu */}
      {isCreateMenuOpen && canCreate && (
        <div className="md:hidden mt-3 py-3 border-t border-primary/20">
          <div className="flex flex-col space-y-3 px-4">
            <Link
              href="/criar/curso"
              className="flex items-center text-text hover:text-primary py-2 transition-colors"
              onClick={() => {
                setIsCreateMenuOpen(false)
                setIsMenuOpen(false)
              }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 mr-2 text-primary"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
                />
              </svg>
              Criar Curso
            </Link>
            <Link
              href="/criar/evento"
              className="flex items-center text-text hover:text-primary py-2 transition-colors"
              onClick={() => {
                setIsCreateMenuOpen(false)
                setIsMenuOpen(false)
              }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 mr-2 text-primary"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                />
              </svg>
              Criar Evento
            </Link>
            <Link
              href="/criar/servico"
              className="flex items-center text-text hover:text-primary py-2 transition-colors"
              onClick={() => {
                setIsCreateMenuOpen(false)
                setIsMenuOpen(false)
              }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 mr-2 text-primary"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                />
              </svg>
              Criar Serviço
            </Link>
          </div>
        </div>
      )}

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden mt-3 py-3 border-t border-primary/20">
          <div className="flex flex-col space-y-3 px-4">
            <Link
              href="/cursos"
              className="text-text hover:text-primary py-2 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Cursos
            </Link>
            <Link
              href="/servicos"
              className="text-text hover:text-primary py-2 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Serviços
            </Link>
            <Link
              href="/eventos"
              className="text-text hover:text-primary py-2 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Eventos
            </Link>
            <Link
              href="/empregos"
              className="text-text hover:text-primary py-2 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Empregos
            </Link>
            <Link
              href="/lojas"
              className="text-text hover:text-primary py-2 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Lojas
            </Link>
            <Link
              href="/chat"
              className="text-text hover:text-primary py-2 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Chat
            </Link>

            <div className="flex space-x-3 pt-2">
              {!isAuthenticated ? (
                <>
                  <Link href="/auth/login">
                    <Button variant="outline" size="sm" fullWidth>
                      Entrar
                    </Button>
                  </Link>
                  <Link href="/auth/registrar">
                    <Button size="sm" fullWidth>
                      Cadastrar
                    </Button>
                  </Link>
                </>
              ) : (
                <>
                  <Link href="/perfil">
                    <Button variant="outline" size="sm" fullWidth>
                      Perfil
                    </Button>
                  </Link>
                  <Button size="sm" onClick={handleLogout} fullWidth>
                    Sair
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  )
}

export default Navbar
