"use client"

import { useState } from "react"
import PropTypes from "prop-types"
import Link from "next/link"
import Avatar from "../ui/Avatar"
import Button from "../ui/Button"

const Comment = ({ comment, isReply = false }) => {
  const [isLiked, setIsLiked] = useState(false)
  const [likeCount, setLikeCount] = useState(comment.likes)
  const [showReplyForm, setShowReplyForm] = useState(false)
  const [replyContent, setReplyContent] = useState("")
  const [replies, setReplies] = useState(comment.replies || [])
  const [showReplies, setShowReplies] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleLike = () => {
    if (isLiked) {
      setLikeCount(likeCount - 1)
    } else {
      setLikeCount(likeCount + 1)
    }
    setIsLiked(!isLiked)
  }

  const toggleReplyForm = () => {
    setShowReplyForm(!showReplyForm)
  }

  const toggleReplies = () => {
    setShowReplies(!showReplies)
  }

  const handleSubmitReply = (e) => {
    e.preventDefault()
    if (!replyContent.trim()) return

    setIsSubmitting(true)

    // Simulando envio para API
    setTimeout(() => {
      const reply = {
        id: `reply-${Date.now()}`,
        author: {
          id: "current-user",
          name: "Você",
          avatar: "/placeholder.svg?height=40&width=40",
        },
        content: replyContent,
        date: "Agora mesmo",
        likes: 0,
        replies: [],
      }

      setReplies([...replies, reply])
      setReplyContent("")
      setShowReplyForm(false)
      setShowReplies(true)
      setIsSubmitting(false)
    }, 500)
  }

  return (
    <div className={`${isReply ? "ml-12 mt-3" : ""}`}>
      <div className="flex items-start space-x-3">
        <Avatar src={comment.author.avatar} alt={comment.author.name} size={isReply ? "sm" : "md"} />
        <div className="flex-grow">
          <div className="bg-background-light p-3 rounded-lg">
            <div className="flex items-center mb-1">
              <Link href={`/perfil/${comment.author.id}`} className="font-medium text-text hover:text-primary">
                {comment.author.name}
              </Link>
              <span className="text-text-muted text-xs ml-2">{comment.date}</span>
            </div>
            <p className="text-text">{comment.content}</p>
          </div>

          <div className="flex items-center mt-1 space-x-4">
            <button
              onClick={handleLike}
              className={`text-xs flex items-center ${
                isLiked ? "text-primary" : "text-text-muted"
              } hover:text-primary transition-colors`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-4 w-4 mr-1"
                fill={isLiked ? "currentColor" : "none"}
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                />
              </svg>
              {likeCount > 0 && likeCount}
            </button>

            {!isReply && (
              <button
                onClick={toggleReplyForm}
                className="text-xs text-text-muted hover:text-primary transition-colors"
              >
                Responder
              </button>
            )}

            {!isReply && replies.length > 0 && (
              <button onClick={toggleReplies} className="text-xs text-text-muted hover:text-primary transition-colors">
                {showReplies
                  ? "Ocultar respostas"
                  : `Ver ${replies.length} ${replies.length === 1 ? "resposta" : "respostas"}`}
              </button>
            )}
          </div>

          {showReplyForm && (
            <form onSubmit={handleSubmitReply} className="mt-3">
              <textarea
                value={replyContent}
                onChange={(e) => setReplyContent(e.target.value)}
                placeholder="Escreva uma resposta..."
                className="w-full bg-background border border-primary/30 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 text-text resize-none min-h-[60px]"
                required
              />
              <div className="flex justify-end mt-2 space-x-2">
                <Button type="button" variant="outline" size="sm" onClick={() => setShowReplyForm(false)}>
                  Cancelar
                </Button>
                <Button type="submit" size="sm" disabled={isSubmitting}>
                  {isSubmitting ? "Enviando..." : "Responder"}
                </Button>
              </div>
            </form>
          )}

          {!isReply && showReplies && replies.length > 0 && (
            <div className="mt-3 space-y-3">
              {replies.map((reply) => (
                <Comment key={reply.id} comment={reply} isReply={true} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

Comment.propTypes = {
  comment: PropTypes.shape({
    id: PropTypes.string.isRequired,
    author: PropTypes.shape({
      id: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      avatar: PropTypes.string,
    }).isRequired,
    content: PropTypes.string.isRequired,
    date: PropTypes.string.isRequired,
    likes: PropTypes.number.isRequired,
    replies: PropTypes.array,
  }).isRequired,
  isReply: PropTypes.bool,
}

export default Comment
