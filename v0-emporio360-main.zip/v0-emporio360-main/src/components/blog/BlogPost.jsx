"use client"

import { useState } from "react"
import PropTypes from "prop-types"
import Link from "next/link"
import Card from "../ui/Card"
import Badge from "../ui/Badge"
import Button from "../ui/Button"
import Avatar from "../ui/Avatar"
import CommentSection from "./CommentSection"

const BlogPost = ({ id, author, title, content, image, date, category, likes, comments, isDetailed = false }) => {
  const [isLiked, setIsLiked] = useState(false)
  const [likeCount, setLikeCount] = useState(likes)
  const [showComments, setShowComments] = useState(isDetailed)

  const handleLike = () => {
    if (isLiked) {
      setLikeCount(likeCount - 1)
    } else {
      setLikeCount(likeCount + 1)
    }
    setIsLiked(!isLiked)
  }

  const toggleComments = () => {
    setShowComments(!showComments)
  }

  return (
    <Card className="mb-6 overflow-hidden">
      {/* Author info */}
      <div className="flex items-center p-4 border-b border-primary/10">
        <Avatar src={author.avatar} alt={author.name} size="md" />
        <div className="ml-3">
          <Link href={`/perfil/${author.id}`} className="font-medium text-text hover:text-primary">
            {author.name}
          </Link>
          <p className="text-text-muted text-sm">{date}</p>
        </div>
        <Badge variant="secondary" className="ml-auto">
          {category}
        </Badge>
      </div>

      {/* Post content */}
      <div className="p-4">
        <Link href={isDetailed ? "#" : `/chat/blog/${id}`}>
          <h3 className="text-xl font-semibold mb-3 hover:text-primary transition-colors">{title}</h3>
        </Link>

        <div className="prose prose-invert max-w-none mb-4">
          {isDetailed ? (
            <div dangerouslySetInnerHTML={{ __html: content }} />
          ) : (
            <p className="text-text-muted">{content.length > 200 ? content.substring(0, 200) + "..." : content}</p>
          )}
        </div>

        {image && (
          <div className="mb-4 rounded-lg overflow-hidden">
            <img src={image || "/placeholder.svg"} alt={title} className="w-full h-auto" />
          </div>
        )}

        {/* Action buttons */}
        <div className="flex items-center justify-between mt-4 pt-3 border-t border-primary/10">
          <div className="flex space-x-4">
            <button
              onClick={handleLike}
              className={`flex items-center text-sm ${
                isLiked ? "text-primary" : "text-text-muted"
              } hover:text-primary transition-colors`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 mr-1"
                fill={isLiked ? "currentColor" : "none"}
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                />
              </svg>
              {likeCount} {likeCount === 1 ? "Curtida" : "Curtidas"}
            </button>

            <button
              onClick={toggleComments}
              className="flex items-center text-sm text-text-muted hover:text-primary transition-colors"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 mr-1"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                />
              </svg>
              {comments.length} {comments.length === 1 ? "Comentário" : "Comentários"}
            </button>

            <button className="flex items-center text-sm text-text-muted hover:text-primary transition-colors">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 mr-1"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"
                />
              </svg>
              Compartilhar
            </button>
          </div>

          {!isDetailed && (
            <Link href={`/chat/blog/${id}`}>
              <Button variant="outline" size="sm">
                Ler mais
              </Button>
            </Link>
          )}
        </div>
      </div>

      {/* Comments section */}
      {showComments && <CommentSection postId={id} comments={comments} />}
    </Card>
  )
}

BlogPost.propTypes = {
  id: PropTypes.string.isRequired,
  author: PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    avatar: PropTypes.string,
  }).isRequired,
  title: PropTypes.string.isRequired,
  content: PropTypes.string.isRequired,
  image: PropTypes.string,
  date: PropTypes.string.isRequired,
  category: PropTypes.string.isRequired,
  likes: PropTypes.number.isRequired,
  comments: PropTypes.array.isRequired,
  isDetailed: PropTypes.bool,
}

export default BlogPost
