"use client"

import { useState } from "react"
import PropTypes from "prop-types"
import Card from "../ui/Card"
import Button from "../ui/Button"
import Avatar from "../ui/Avatar"
import Select from "../ui/Select"

const CreatePostForm = ({ onPostCreated }) => {
  const [isExpanded, setIsExpanded] = useState(false)
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [category, setCategory] = useState("geral")
  const [image, setImage] = useState(null)
  const [imagePreview, setImagePreview] = useState(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const categories = [
    { value: "geral", label: "Geral" },
    { value: "tecnologia", label: "Tecnologia" },
    { value: "educacao", label: "Educação" },
    { value: "negocios", label: "Negócios" },
    { value: "saude", label: "Saúde" },
    { value: "arte", label: "Arte e Cultura" },
  ]

  const handleExpand = () => {
    setIsExpanded(true)
  }

  const handleCancel = () => {
    setIsExpanded(false)
    setTitle("")
    setContent("")
    setCategory("geral")
    setImage(null)
    setImagePreview(null)
  }

  const handleImageChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      setImage(file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setImagePreview(reader.result)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!title.trim() || !content.trim()) return

    setIsSubmitting(true)

    // Simulando envio para API
    setTimeout(() => {
      const newPost = {
        id: `post-${Date.now()}`,
        author: {
          id: "current-user",
          name: "Você",
          avatar: "/placeholder.svg?height=40&width=40",
        },
        title,
        content,
        image: imagePreview,
        date: "Agora mesmo",
        category: categories.find((c) => c.value === category).label,
        likes: 0,
        comments: [],
      }

      onPostCreated(newPost)
      handleCancel()
      setIsSubmitting(false)
    }, 1000)
  }

  return (
    <Card className="mb-6">
      <form onSubmit={handleSubmit}>
        <div className="p-4">
          {!isExpanded ? (
            <div className="flex items-center space-x-3">
              <Avatar src="/placeholder.svg?height=40&width=40" alt="Seu Avatar" size="md" />
              <div
                onClick={handleExpand}
                className="flex-grow bg-background-light border border-primary/30 rounded-md px-4 py-3 cursor-text text-text-muted"
              >
                O que você gostaria de compartilhar hoje?
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Avatar src="/placeholder.svg?height=40&width=40" alt="Seu Avatar" size="md" />
                <div className="flex-grow">
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Título da sua publicação"
                    className="w-full bg-background-light border border-primary/30 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 text-text mb-2"
                    required
                  />
                  <textarea
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder="Compartilhe seus pensamentos, conhecimentos ou faça uma pergunta..."
                    className="w-full bg-background-light border border-primary/30 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 text-text resize-none min-h-[120px]"
                    required
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-4">
                <div className="w-full md:w-auto">
                  <Select
                    id="category"
                    options={categories}
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full md:w-48"
                  />
                </div>

                <div className="flex-grow">
                  <label
                    htmlFor="image-upload"
                    className="flex items-center text-text-muted hover:text-primary cursor-pointer transition-colors"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5 mr-2"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                      />
                    </svg>
                    Adicionar imagem
                    <input
                      type="file"
                      id="image-upload"
                      accept="image/*"
                      onChange={handleImageChange}
                      className="hidden"
                    />
                  </label>
                </div>

                <div className="flex space-x-2 ml-auto">
                  <Button type="button" variant="outline" onClick={handleCancel}>
                    Cancelar
                  </Button>
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? "Publicando..." : "Publicar"}
                  </Button>
                </div>
              </div>

              {imagePreview && (
                <div className="relative mt-2">
                  <img src={imagePreview || "/placeholder.svg"} alt="Preview" className="max-h-48 rounded-md" />
                  <button
                    type="button"
                    onClick={() => {
                      setImage(null)
                      setImagePreview(null)
                    }}
                    className="absolute top-2 right-2 bg-background/80 text-text p-1 rounded-full hover:bg-primary/80 transition-colors"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </form>
    </Card>
  )
}

CreatePostForm.propTypes = {
  onPostCreated: PropTypes.func.isRequired,
}

export default CreatePostForm
