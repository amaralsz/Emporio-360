"use client"

import { useState } from "react"
import PropTypes from "prop-types"
import Avatar from "../ui/Avatar"
import Button from "../ui/Button"
import Comment from "./Comment"

const CommentSection = ({ postId, comments: initialComments }) => {
  const [comments, setComments] = useState(initialComments)
  const [newComment, setNewComment] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!newComment.trim()) return

    setIsSubmitting(true)

    // Simulando envio para API
    setTimeout(() => {
      const comment = {
        id: `comment-${Date.now()}`,
        author: {
          id: "current-user",
          name: "Você",
          avatar: "/placeholder.svg?height=40&width=40",
        },
        content: newComment,
        date: "Agora mesmo",
        likes: 0,
        replies: [],
      }

      setComments([comment, ...comments])
      setNewComment("")
      setIsSubmitting(false)
    }, 500)
  }

  return (
    <div className="border-t border-primary/10 p-4">
      <h4 className="text-lg font-semibold mb-4">Comentários</h4>

      {/* Comment form */}
      <form onSubmit={handleSubmit} className="mb-6">
        <div className="flex items-start space-x-3">
          <Avatar src="/placeholder.svg?height=40&width=40" alt="Seu Avatar" size="md" />
          <div className="flex-grow">
            <textarea
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Escreva um comentário..."
              className="w-full bg-background-light border border-primary/30 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 text-text resize-none min-h-[80px]"
              required
            />
            <div className="flex justify-end mt-2">
              <Button type="submit" size="sm" disabled={isSubmitting}>
                {isSubmitting ? "Enviando..." : "Comentar"}
              </Button>
            </div>
          </div>
        </div>
      </form>

      {/* Comments list */}
      <div className="space-y-4">
        {comments.length > 0 ? (
          comments.map((comment) => <Comment key={comment.id} comment={comment} />)
        ) : (
          <p className="text-text-muted text-center py-4">Seja o primeiro a comentar!</p>
        )}
      </div>
    </div>
  )
}

CommentSection.propTypes = {
  postId: PropTypes.string.isRequired,
  comments: PropTypes.array.isRequired,
}

export default CommentSection
